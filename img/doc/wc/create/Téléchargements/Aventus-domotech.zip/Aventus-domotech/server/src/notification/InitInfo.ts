import { ClientConnection } from '../Connection';

export class InitInfo {
	public static isInit: boolean = false;
	public static send(txt: string) {
		ClientConnection.getInstance().sendNotification("aventus/init", txt);
	}
}