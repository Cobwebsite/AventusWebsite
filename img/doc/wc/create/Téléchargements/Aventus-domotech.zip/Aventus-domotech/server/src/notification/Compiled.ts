import { ClientConnection } from '../Connection';
import { InitInfo } from './InitInfo';

export class Compiled {
	public static send(buildName: string) {
		if (InitInfo.isInit) {
			ClientConnection.getInstance().sendNotification("aventus/compiled", buildName);
		}
	}
}