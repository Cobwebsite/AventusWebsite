var AventusTest;
(AventusTest||(AventusTest = {}));
(function (AventusTest) {
 var namespace = 'AventusTest';
})(AventusTest);
