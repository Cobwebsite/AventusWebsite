import { Singleton } from "../Singleton";

export class InitInfo {
	public static cmd: string = "aventus/init";

	public static action(txt: string) {
		if (Singleton.client.components) {
			Singleton.client.components.lastCompiledInfo.text = txt;
		}
		if (txt == "Aventus : Done") {
			Singleton.client.startFileSystem();
		}
	}
}