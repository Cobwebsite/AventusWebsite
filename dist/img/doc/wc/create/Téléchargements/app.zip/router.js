var fs = require('fs');
var pug = require('pug');

class RouterIPC {
    constructor() {
        this.routes = {};
        this.middlewares = {};
        this.prefix = '';
        this.modules = [];
        this.isFirst = true;
        this.message = {
            headers: {
                status: 200,
                error: '',
                session: {}
            },
            body: {

            }
        }
        this.session = {
            
        };
    }
    get() { }
    post() { }
    copyMsg() {
        var msg = { ...this.message };
        msg.headers.session = this.session;
        return msg;
    }

    route(path, cb) {
        if (path == '/') {
            this.routes[this.prefix] = cb;
        }
        path = this.prefix + path;
        this.routes[path] = cb;
    }

    use(cb) {
        if (!this.middlewares.hasOwnProperty(this.prefix)) {
            this.middlewares[this.prefix] = []
        }
        this.middlewares[this.prefix].push(cb);
    }

    serve(url, headers, body, event) {
        var that = this;
        var session = this.session;
        headers = { ...headers, session };
        event.res = function (body) {
            var returnMsg = { ...that.message };
            returnMsg.body = body;
            this.returnValue = JSON.stringify(returnMsg);
            if(that.isFirst){
                that.isFirst = false;
                that.initModule();
            }
        }
        var cpt = -1;
        var next = function () {
            cpt++;
            if (cpt < Object.keys(that.middlewares).length) {
                var key = Object.keys(that.middlewares)[cpt];
                if (url.startsWith(key)) {
                    that.middlewares[key][0](headers, body, event, next);
                }
                else {
                    next();
                }
            }
            else {
                normalRoute();
            }
        }

        var normalRoute = function () {
            if (that.routes[url]) {
                that.routes[url](headers, body, event);
            }
            else {
                var msg404 = { ...that.message };
                msg404.headers.status = 404;
                msg404.headers.error = 'URL not found';
                msg404.body = pug.renderFile(__dirname + '/express-app/views/error.pug')
                event.returnValue = JSON.stringify(msg404);
            }
        }

        next();
    }
    redirect(url, event, headers = {}, body = {}) {
        this.serve(url, headers, body, event);
    }

    reload(force) {
        if (force) {
            this.clearCache();
        }
        this.routes = {};
        require('./express-app/routes/admin.js');
        require('./express-app/routes/index.js');
        // var files = fs.readdirSync(__dirname + '/express-app/routes');
        // for (var i = 0; i < files.length; i++) {
        //     var current = files[i];
        //     var name = current.split('.')[0]
        //     require('./express-app/routes/' + name);

        // }

    }
    clearCache() {
        Object.keys(require.cache).forEach(function (key) {
            if (key.indexOf('\\node_modules\\') == -1 && !key.endsWith("routerIO.js")) {
                delete require.cache[key]
            }
        })
    }

    addModule(module) {
        this.modules.push(module);
    }
    initModule() {
        for (var i = 0; i < this.modules.length; i++) {
            this.modules[i].init();
        }
    }
}

class Singleton {

    constructor() {
        if (!Singleton.instance) {
            Singleton.instance = new RouterIPC();
        }
    }
    /**
     * @returns {RouterIPC}
     */
    getInstance() {
        return Singleton.instance;
    }

}

module.exports = Singleton;