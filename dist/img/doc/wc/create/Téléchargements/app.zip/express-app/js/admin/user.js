$(document).ready(function () {
    $('select').formSelect();
    $('.modal').modal();
    $("#infoUser input").prop("disabled", "disabled");
    $("#infoUser #type").prop("disabled", "disabled");
    M.updateTextFields();
});

function modify(t) {
    $("#infoUser input").removeAttr("disabled");
    $("#infoUser input").removeProp("disabled");
    $("#infoUser #type").removeAttr("disabled");
    $("#infoUser #type").removeProp("disabled");
    $(t).html("Valider");
    $(t).removeAttr('onclick');
    $(t).attr('onclick', "validate(this)");
}

function validate(t) {
    var idUser = document.getElementById('idUser').value;
    var nom = document.getElementById("nom").value;
    var prenom = document.getElementById("prenom").value;
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    var type = document.getElementById('type').value;
    var email = document.getElementById("email").value;
    if (nom.length == 0) {
        return;
    }
    if (prenom.length == 0) {
        return;
    }
    if (username.length == 0) {
        return;
    }

    var msgToSend = JSON.parse(JSON.stringify(msg));
    msgToSend.headers.url = '/admin/user/update';
    msgToSend.headers.params.id = idUser;
    msgToSend.body = {
        nom: nom,
        prenom: prenom,
        username: username,
        isAdmin: type,
        password: password,
        email: email
    }
    loadPage(msgToSend);
}

function getRapport() {
    var idUser = document.getElementById('idUser').value;
    var month = document.getElementById("mois").value;
    var year = document.getElementById("annee").value;
    var fullYear = document.getElementById("fullYear").checked;
    var msgToSend = JSON.parse(JSON.stringify(msg));
    msgToSend.headers.url = '/admin/user/rapport';
    msgToSend.headers.params = {
        id: idUser,
        annee: year,
        mois: month,
        fullYear: fullYear
    }
    sendRequest(msgToSend, true, function () {
        document.getElementById("contLoader").style.display = "none";
    })
}

function getRapportDet() {
    var idUser = document.getElementById('idUser').value;
    var month = document.getElementById("mois_det").value;
    var year = document.getElementById("annee_det").value;
    var fullYear = document.getElementById("fullYearDetails").checked;
    var msgToSend = JSON.parse(JSON.stringify(msg));
    msgToSend.headers.url = '/admin/user/rapport_det';
    msgToSend.headers.params = {
        id: idUser,
        annee: year,
        mois: month,
        fullYear: fullYear
    }
    sendRequest(msgToSend, true, function () {
        document.getElementById("contLoader").style.display = "none";
    })
}

function changeFullYear() {
    let el = document.getElementById("mois").parentNode.children[0];
    if (document.getElementById("fullYear").checked) {
        el.setAttribute("disabled", "disabled");
    }
    else {
        el.removeAttribute("disabled");

    }

}
function changeFullYearDetails() {
    let el = document.getElementById("mois_det").parentNode.children[0];
    if (document.getElementById("fullYearDetails").checked) {
        el.setAttribute("disabled", "disabled");
    }
    else {
        el.removeAttribute("disabled");

    }
}