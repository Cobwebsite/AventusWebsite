var axios
var qs
var Excel
var home
var path
var fs
var emailModule
var settingsModule
var opn
var tailleTitre = 5;
var nomsDesJours = new Array("Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi");
var nomsDesMois = new Array("Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre");
var cells = ["A", "B", "C", "D", "E", "F", "G"];


var self = module.exports = {
    init() {
        axios = require('axios');
        qs = require('qs');
        Excel = require('exceljs');
        home = require("os").homedir();
        path = require('path');
        fs = require('fs');
        emailModule = require('./email');
        settingsModule = require('./settings');
        opn = require('opn');
    },
    getAllMonthRapport(users, index, year, month, req, printWorkBook) {
        return new Promise((resolve, reject) => {
            if (printWorkBook == null) {
                printWorkBook = new Excel.Workbook();
            }

            if (index == users.length) {
                if (index > 0) {
                    var pathSave = home + '/Documents/Cordonier Horaire';
                    pathSave += '/Rapports Automatiques';
                    pathSave += '/' + year;
                    pathSave += '/' + nomsDesMois[month];
                    pathSave += '/_impression.xlsx';
                    pathSave = path.normalize(pathSave);
                    printWorkBook.xlsx.writeFile(pathSave).then(() => {
                        opn(home + '/Documents/Cordonier Horaire/Rapports Automatiques/' + year + '/' + nomsDesMois[month]);
                        resolve();
                    })
                }
                resolve();
            } else {
                self.getOneRapport(users[index], year, month, req, false, printWorkBook).then(() => {
                    self.getAllMonthRapport(users, index + 1, year, month, req, printWorkBook).then(() => {
                        resolve();
                    })
                })
            }
        })
    },
    getOneRapport(user, year, month, req, open, printWorkBook) {
        return new Promise((resolve, reject) => {
            var workbook = new Excel.Workbook();
            var sheet = workbook.addWorksheet('Rapport par mois');

            sheet.getColumn(1).width = 12.8;
            sheet.getColumn(2).width = 8.8;
            sheet.getColumn(3).width = 16.86;
            sheet.getColumn(4).width = 16.86;
            sheet.getColumn(5).width = 8.8;
            sheet.getColumn(6).width = 16.86;


            sheet = self._generateTitle(sheet, user);
            sheet = self._generateSubTitle(sheet, year, month);
            sheet = self._generateLabel(sheet);

            self._generateRapport(sheet, year, month, user.idUser, req).then(() => {
                if (printWorkBook) {
                    var sheetPrint = printWorkBook.addWorksheet('Rapport_' + user.nom + "_" + user.prenom);
                    sheetPrint.getColumn(1).width = 12.8;
                    sheetPrint.getColumn(2).width = 8.8;
                    sheetPrint.getColumn(3).width = 16.86;
                    sheetPrint.getColumn(4).width = 16.86;
                    sheetPrint.getColumn(5).width = 8.8;
                    sheetPrint.getColumn(6).width = 16.86;
                    sheetPrint = self._generateTitle(sheetPrint, user);
                    sheetPrint = self._generateSubTitle(sheetPrint, year, month);
                    sheetPrint = self._generateLabel(sheetPrint);
                    self._generateRapport(sheetPrint, year, month, user.idUser, req).then(() => {
                        self._save(workbook, user, year, month, open).then(() => {
                            resolve()
                        })
                    })
                }
                else {
                    self._save(workbook, user, year, month, open).then(() => {
                        resolve()
                    })
                }
            })
        })
    },
    getOneRapportFullYear(user, year, req, open) {
        return new Promise(async (resolve, reject) => {
            var workbook = new Excel.Workbook();
            for (let month = 0; month < 12; month++) {
                var sheet = workbook.addWorksheet(nomsDesMois[month]);
                sheet.getColumn(1).width = 12.8;
                sheet.getColumn(2).width = 8.8;
                sheet.getColumn(3).width = 16.86;
                sheet.getColumn(4).width = 16.86;
                sheet.getColumn(5).width = 8.8;
                sheet.getColumn(6).width = 16.86;


                sheet = self._generateTitle(sheet, user);
                sheet = self._generateSubTitle(sheet, year, month);
                sheet = self._generateLabel(sheet);

                await self._generateRapport(sheet, year, month, user.idUser, req);
            }
            self._save(workbook, user, year, null, open).then(() => {
                resolve()
            })
        })
    },
    getOneRapportDetails(user, year, month, req, open) {
        return new Promise((resolve, reject) => {
            var workbook = new Excel.Workbook();
            var sheet = workbook.addWorksheet('Rapport par mois');

            sheet.getColumn(1).width = 12.8;
            sheet.getColumn(2).width = 8.8;
            sheet.getColumn(3).width = 16.86;
            sheet.getColumn(4).width = 16.86;
            sheet.getColumn(5).width = 8.8;
            sheet.getColumn(6).width = 16.86;


            sheet = self._generateTitleDetails(sheet, user);
            sheet = self._generateSubTitleDetails(sheet, year, month);
            sheet = self._generateLabelDetails(sheet);
            self._generateRapportDetails(sheet, year, month, user.idUser, req).then(() => {
                self._save(workbook, user, year, month, open).then(() => {
                    resolve()
                })
            })
        })
    },
    getOneRapportDetailsFullYear(user, year, req, open) {
        return new Promise(async (resolve, reject) => {
            var workbook = new Excel.Workbook();
            for (let month = 0; month < 12; month++) {
                var sheet = workbook.addWorksheet(nomsDesMois[month]);
                sheet.getColumn(1).width = 12.8;
                sheet.getColumn(2).width = 8.8;
                sheet.getColumn(3).width = 16.86;
                sheet.getColumn(4).width = 16.86;
                sheet.getColumn(5).width = 8.8;
                sheet.getColumn(6).width = 16.86;
    
    
                sheet = self._generateTitleDetails(sheet, user);
                sheet = self._generateSubTitleDetails(sheet, year, month);
                sheet = self._generateLabelDetails(sheet);
                await self._generateRapportDetails(sheet, year, month, user.idUser, req)
            }
            self._save(workbook, user, year, null, open, user.nom + " " + user.prenom + " Details " + year + ".xlsx").then(() => {
                resolve()
            })
        })
    },
    _generateTitle(sheet, user) {
        sheet.mergeCells('A1:G2');
        sheet.getCell('A1').value = user.nom + ' ' + user.prenom;
        sheet.getCell('A1').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };
        var font = {
            name: 'Arial',
            size: 18,
            bold: true
        };
        sheet.getCell('A1').font = font;
        return sheet;
    },
    _generateTitleDetails(sheet, user) {
        sheet.mergeCells('A1:H2');
        sheet.getCell('A1').value = user.nom + ' ' + user.prenom;
        sheet.getCell('A1').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };
        var font = {
            name: 'Arial',
            size: 18,
            bold: true
        };
        sheet.getCell('A1').font = font;
        return sheet;
    },
    _generateSubTitle(sheet, year, month) {
        sheet.mergeCells('A3:G3');
        sheet.getCell('A3').value = 'Rapport de ' + nomsDesMois[month] + " " + year;
        sheet.getCell('A3').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };
        var font = {
            name: 'Arial',
            size: 12
        };
        sheet.getCell('A3').font = font;
        return sheet;
    },
    _generateSubTitleDetails(sheet, year, month) {
        sheet.mergeCells('A3:H3');
        sheet.getCell('A3').value = 'Rapport de ' + nomsDesMois[month] + " " + year;
        sheet.getCell('A3').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };
        var font = {
            name: 'Arial',
            size: 12
        };
        sheet.getCell('A3').font = font;
        return sheet;
    },
    _generateLabel(sheet) {
        sheet.mergeCells('A4:B4');
        sheet.getCell("A4").value = "Jour"
        sheet.getCell('A4').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };
        sheet.getCell("C4").value = "Heure prévue"
        sheet.getCell('C4').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };

        sheet.getCell("D4").value = "Heure faite"
        sheet.getCell('D4').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };

        sheet.getCell("E4").value = "Repas"
        sheet.getCell('E4').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };

        sheet.getCell("F4").value = "Déplacement"
        sheet.getCell('F4').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };

        sheet.getCell("G4").value = "Maladie"
        sheet.getCell('G4').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };
        return sheet;
    },
    _generateLabelDetails(sheet) {
        sheet.mergeCells('A4:B4');
        sheet.getCell("A4").value = "Jour"
        sheet.getCell('A4').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };
        sheet.getCell("C4").value = "Heure prévue"
        sheet.getCell('C4').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };

        sheet.getCell("D4").value = "Chantier"
        sheet.getCell('D4').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };
        sheet.getCell("E4").value = "Heure faite"
        sheet.getCell('E4').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };

        sheet.getCell("F4").value = "Repas"
        sheet.getCell('F4').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };

        sheet.getCell("G4").value = "Déplacement"
        sheet.getCell('G4').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };

        sheet.getCell("H4").value = "Maladie"
        sheet.getCell('H4').alignment = {
            vertical: 'middle',
            horizontal: 'center'
        };
        return sheet;
    },
    _generateRapport(sheet, year, month, idUser, req) {
        return new Promise((resolve, reject) => {
            var monthToSend = Number(month) + 1;
            var nbJour = new Date(year, month + 1, 0).getDate();
            if (monthToSend < 10) {
                monthToSend = '0' + monthToSend;
            }
            axios({
                method: 'post',
                url: 'http://cordonierhoraire.cobwebsite.ch/api/planing/getAllByYearAndMonth?token=' + req.session.token,
                data: qs.stringify({
                    annee: year,
                    mois: monthToSend,
                    idUser: idUser
                })
            })
                .then(function (response) {


                    var planing = response.data[0];
                    var horaire = response.data[1];
                    var repas = response.data[2];
                    var deplacement = response.data[3];
                    var maladies = response.data[4];
                    deplacement.sort(function (a, b) {
                        a = new Date(a.date);
                        b = new Date(b.date);
                        return a > b ? -1 : a < b ? 1 : 0;
                    });

                    var j = 0;
                    var k = 0;
                    var l = 0;
                    var m = 0;
                    for (var i = 0; i < nbJour; i++) {
                        var currentDate = new Date(year, month, i + 1);
                        var currentMonth = currentDate.getMonth() + 1;
                        if (currentMonth < 10) {
                            currentMonth = '0' + currentMonth;
                        }
                        var currentDay = i + 1;
                        if (currentDay < 10) {
                            currentDay = '0' + currentDay;
                        }
                        var currentDateText = currentDate.getFullYear() + '-' + currentMonth + '-' + currentDay;

                        // information sur le planing
                        if (j < planing.length && planing[j]['date'] == currentDateText) {
                            if (planing[j]['nbHeure'] < 0) {
                                for (var c = 0; c < cells.length; c++) {
                                    sheet.getCell(cells[c] + (i + tailleTitre)).fill = {
                                        type: 'pattern',
                                        pattern: 'solid',
                                        fgColor: {
                                            argb: '808080'
                                        }
                                    }
                                }
                                sheet.getCell('C' + (i + tailleTitre)).value = Number(0)
                            } else {
                                sheet.getCell('C' + (i + tailleTitre)).value = Number(planing[j]['nbHeure'])
                            }
                            j++;
                        } else {
                            for (var c = 0; c < cells.length; c++) {
                                sheet.getCell(cells[c] + (i + tailleTitre)).fill = {
                                    type: 'pattern',
                                    pattern: 'solid',
                                    fgColor: {
                                        argb: 'FFFF0000'
                                    }
                                }
                            }
                            sheet.getCell('C' + (i + tailleTitre)).value = '?';
                        }

                        //Heure faite

                        if (k < horaire.length && horaire[k]['date'] == currentDateText) {
                            var tot = 0;
                            while (horaire[k]['date'] == currentDateText) {
                                if (horaire[k]['idChantier'] < 0) {
                                    tot = Number(horaire[k]['idChantier']);
                                    k++;
                                } else {
                                    tot += Number(horaire[k]['nbHeure']);
                                    k++;
                                }
                                if (k == horaire.length) {
                                    break;
                                }
                            }
                            if (tot > 0) {
                                sheet.getCell('D' + (i + tailleTitre)).value = tot;
                            } else {
                                if (tot == -2) {
                                    sheet.getCell('D' + (i + tailleTitre)).value = "Congé";
                                }
                                else if (tot == -1) {
                                    sheet.getCell('D' + (i + tailleTitre)).value = "Armée";
                                }
                                else if (tot == -3) {
                                    sheet.getCell('D' + (i + tailleTitre)).value = "Décès";
                                }
                            }
                        } else {
                            sheet.getCell('D' + (i + tailleTitre)).value = Number('0');
                        }

                        if (l < repas.length && repas[l]['date'] == currentDateText) {

                            sheet.getCell('E' + (i + tailleTitre)).value = "X";
                            l++;
                        }

                        if (l < maladies.length && maladies[l]['date'] == currentDateText) {
                            sheet.getCell('G' + (i + tailleTitre)).value = maladies[l]['maladiePercent'] + "%";
                        }

                        if (m < deplacement.length && deplacement[m]["date"] == currentDateText) {
                            if (deplacement[m]['distance'].startsWith("id")) {
                                var nom = deplacement[m]["nom"];
                                sheet.getCell("F" + (i + tailleTitre)).value = nom;
                            } else {
                                sheet.getCell("F" + (i + tailleTitre)).value = deplacement[m]['distance'] + " Km";
                            }
                            m++;
                        }

                        sheet.getCell('A' + (i + tailleTitre)).value = nomsDesJours[currentDate.getDay()]
                        sheet.getCell('B' + (i + tailleTitre)).value = (i + 1);
                        sheet.getCell('B' + (i + tailleTitre)).alignment = {
                            vertical: 'middle',
                            horizontal: 'center'
                        };

                        sheet.getCell('C' + (i + tailleTitre)).alignment = {
                            vertical: 'middle',
                            horizontal: 'center'
                        };


                        sheet.getCell('D' + (i + tailleTitre)).alignment = {
                            vertical: 'middle',
                            horizontal: 'center'
                        };

                        sheet.getCell('E' + (i + tailleTitre)).alignment = {
                            vertical: 'middle',
                            horizontal: 'center'
                        };

                        sheet.getCell('F' + (i + tailleTitre)).alignment = {
                            vertical: 'middle',
                            horizontal: 'center'
                        };
                        sheet.getCell('G' + (i + tailleTitre)).alignment = {
                            vertical: 'middle',
                            horizontal: 'center'
                        };

                    }

                    /**
                     * TOTAL
                     */
                    sheet.mergeCells('A' + (i + tailleTitre) + ":B" + (i + tailleTitre));
                    sheet.getCell('A' + (i + tailleTitre)).value = "Total";
                    sheet.getCell('A' + (i + tailleTitre)).alignment = {
                        vertical: 'middle',
                        horizontal: 'center'
                    };
                    var font = {
                        name: 'Arial',
                        size: 11,
                        bold: true
                    };
                    sheet.getCell('A' + (i + tailleTitre)).font = font;

                    sheet.getCell('C' + (i + tailleTitre)).value = {
                        formula: "SUM(C" + tailleTitre + ":C" + (i + tailleTitre - 1) + ")"
                    };
                    sheet.getCell('C' + (i + tailleTitre)).alignment = {
                        vertical: 'middle',
                        horizontal: 'center'
                    };
                    sheet.getCell('D' + (i + tailleTitre)).value = {
                        formula: "SUM(D" + tailleTitre + ":D" + (i + tailleTitre - 1) + ")"
                    };
                    sheet.getCell('D' + (i + tailleTitre)).alignment = {
                        vertical: 'middle',
                        horizontal: 'center'
                    };
                    sheet.getCell('E' + (i + tailleTitre)).value = {
                        formula: 'COUNTA(E' + tailleTitre + ':E' + (i + tailleTitre - 1) + ')'
                    };
                    sheet.getCell('E' + (i + tailleTitre)).alignment = {
                        vertical: 'middle',
                        horizontal: 'center'
                    };

                    resolve();
                })
        })
    },
    _generateRapportDetails(sheet, year, month, idUser, req) {
        return new Promise((resolve, reject) => {
            var monthToSend = Number(month) + 1;
            var nbJour = new Date(year, monthToSend, 0).getDate();
            if (monthToSend < 10) {
                monthToSend = '0' + monthToSend;
            }
            axios({
                method: 'post',
                url: 'http://cordonierhoraire.cobwebsite.ch/api/planing/getAllByYearAndMonth?token=' + req.session.token,
                data: qs.stringify({
                    annee: year,
                    mois: monthToSend,
                    idUser: idUser
                })
            })
                .then(function (response) {
                    var planing = response.data[0];
                    var horaire = response.data[1];
                    var repas = response.data[2];
                    var deplacement = response.data[3];
                    var maladies = response.data[4];
                    deplacement.sort(function (a, b) {
                        a = new Date(a.date);
                        b = new Date(b.date);
                        return a > b ? -1 : a < b ? 1 : 0;
                    });

                    var j = 0;
                    var k = 0;
                    var l = 0;
                    var m = 0;
                    var diff = 0;
                    for (var i = 0; i < nbJour; i++) {
                        var iStart = i + diff + tailleTitre;
                        var iEnd = iStart;
                        var currentDate = new Date(year, month, i + 1);
                        var currentMonth = currentDate.getMonth() + 1;
                        if (currentMonth < 10) {
                            currentMonth = '0' + currentMonth;
                        }
                        var currentDay = i + 1;
                        if (currentDay < 10) {
                            currentDay = '0' + currentDay;
                        }
                        var currentDateText = currentDate.getFullYear() + '-' + currentMonth + '-' + currentDay;

                        //Heure faite
                        if (k < horaire.length && horaire[k]['date'] == currentDateText) {
                            while (horaire[k]['date'] == currentDateText) {
                                sheet.getCell('D' + iEnd).alignment = {
                                    vertical: 'middle',
                                    horizontal: 'center'
                                };

                                sheet.getCell('E' + iEnd).alignment = {
                                    vertical: 'middle',
                                    horizontal: 'center'
                                };
                                if (horaire[k]['idChantier'] == -2) {
                                    sheet.getCell('D' + iEnd).value = "Congé";
                                    sheet.getCell('E' + iEnd).value = "-";
                                    iEnd++;
                                    diff++;
                                    k++;
                                }
                                else if (horaire[k]['idChantier'] == -1) {
                                    sheet.getCell('D' + iEnd).value = "Armée";
                                    sheet.getCell('E' + iEnd).value = "-";
                                    iEnd++;
                                    diff++;
                                    k++;
                                }
                                else if (horaire[k]['idChantier'] == -3) {
                                    sheet.getCell('D' + iEnd).value = "Décès";
                                    sheet.getCell('E' + iEnd).value = "-";
                                    iEnd++;
                                    diff++;
                                    k++;
                                }
                                else {
                                    sheet.getCell('D' + iEnd).value = horaire[k]['chantier'];
                                    sheet.getCell('E' + iEnd).value = Number(horaire[k]['nbHeure']);
                                    iEnd++;
                                    diff++;
                                    k++;
                                }


                                if (k == horaire.length) {
                                    break;
                                }
                            }
                        } else {
                            sheet.getCell('D' + iStart).value = '-';
                            sheet.getCell('E' + iStart).value = Number('0');
                            sheet.getCell('D' + iStart).alignment = {
                                vertical: 'middle',
                                horizontal: 'center'
                            };

                            sheet.getCell('E' + iStart).alignment = {
                                vertical: 'middle',
                                horizontal: 'center'
                            };

                        }

                        // information sur le planing
                        if (j < planing.length && planing[j]['date'] == currentDateText) {
                            if (planing[j]['nbHeure'] < 0) {
                                var cells2 = ["A", "B", "C", "D", "E", "F", "G", "H"];
                                for (var c = 0; c < cells2.length; c++) {
                                    sheet.getCell(cells2[c] + iStart).fill = {
                                        type: 'pattern',
                                        pattern: 'solid',
                                        fgColor: {
                                            argb: '808080'
                                        }
                                    }
                                }
                                sheet.getCell('C' + iStart).value = Number(0)
                            } else {
                                sheet.getCell('C' + iStart).value = Number(planing[j]['nbHeure'])
                            }
                            j++;
                        } else {
                            for (var c = 0; c < cells.length; c++) {
                                sheet.getCell(cells[c] + iStart).fill = {
                                    type: 'pattern',
                                    pattern: 'solid',
                                    fgColor: {
                                        argb: 'FFFF0000'
                                    }
                                }
                            }
                            sheet.getCell('C' + iStart).value = '?';
                        }



                        if (l < repas.length && repas[l]['date'] == currentDateText) {

                            sheet.getCell('F' + iStart).value = "X";
                            l++;
                        }

                        if (l < maladies.length && maladies[l]['date'] == currentDateText) {
                            sheet.getCell('H' + iStart).value = maladies[l]['maladiePercent'] + "%";
                        }

                        if (m < deplacement.length && deplacement[m]["date"] == currentDateText) {
                            if (deplacement[m]['distance'].startsWith("id")) {
                                var nom = deplacement[m]["nom"];
                                sheet.getCell("G" + iStart).value = nom;
                            } else {
                                sheet.getCell("G" + iStart).value = deplacement[m]['distance'] + " Km";
                            }
                            m++;
                        }



                        sheet.getCell('A' + iStart).value = nomsDesJours[currentDate.getDay()]
                        sheet.getCell('B' + iStart).value = (i + 1);
                        sheet.getCell('B' + iStart).alignment = {
                            vertical: 'middle',
                            horizontal: 'center'
                        };
                        sheet.getCell('C' + iStart).alignment = {
                            vertical: 'middle',
                            horizontal: 'center'
                        };



                        sheet.getCell('F' + iStart).alignment = {
                            vertical: 'middle',
                            horizontal: 'center'
                        };
                        sheet.getCell('G' + iStart).alignment = {
                            vertical: 'middle',
                            horizontal: 'center'
                        };
                        sheet.getCell('H' + iStart).alignment = {
                            vertical: 'middle',
                            horizontal: 'center'
                        };

                        if (iStart != iEnd) {
                            diff--;
                            iEnd--;
                            sheet.mergeCells('A' + iStart + ":A" + iEnd);
                            sheet.getCell('A' + iStart).alignment = {
                                vertical: 'middle',
                                horizontal: 'left'
                            };
                            sheet.mergeCells('B' + iStart + ":B" + iEnd);
                            sheet.mergeCells('C' + iStart + ":C" + iEnd);
                            sheet.mergeCells('F' + iStart + ":F" + iEnd);
                            sheet.mergeCells('G' + iStart + ":G" + iEnd);
                            sheet.mergeCells('H' + iStart + ":H" + iEnd);
                        }

                    }

                    /**
                     * TOTAL
                     */
                    var iStart = i + diff + tailleTitre;
                    sheet.mergeCells('A' + iStart + ":B" + iStart);
                    sheet.getCell('A' + iStart).value = "Total";
                    sheet.getCell('A' + iStart).alignment = {
                        vertical: 'middle',
                        horizontal: 'center'
                    };
                    var font = {
                        name: 'Arial',
                        size: 11,
                        bold: true
                    };
                    sheet.getCell('A' + iStart).font = font;

                    sheet.mergeCells('C' + iStart + ":C" + iStart);
                    sheet.getCell('C' + iStart).value = {
                        formula: "SUM(C" + tailleTitre + ":C" + (iStart - 1) + ")"
                    };
                    sheet.getCell('C' + iStart).alignment = {
                        vertical: 'middle',
                        horizontal: 'center'
                    };

                    sheet.getCell('E' + iStart).value = {
                        formula: "SUM(E" + tailleTitre + ":E" + (iStart - 1) + ")"
                    };
                    sheet.getCell('E' + iStart).alignment = {
                        vertical: 'middle',
                        horizontal: 'center'
                    };

                    sheet.getCell('F' + iStart).value = {
                        formula: 'COUNTA(F' + tailleTitre + ':F' + (iStart - 1) + ')'
                    };
                    sheet.getCell('F' + iStart).alignment = {
                        vertical: 'middle',
                        horizontal: 'center'
                    };
                    resolve();
                })
        })
    },
    _save(workbook, user, year, month, open, customFileName) {
        return new Promise((resolve, reject) => {

            var pathSave = home + '/Documents/Cordonier Horaire';
            pathSave = path.normalize(pathSave);
            if (!fs.existsSync(pathSave)) {
                fs.mkdirSync(pathSave);
            }

            pathSave += '/Rapports Automatiques';
            pathSave = path.normalize(pathSave);
            if (!fs.existsSync(pathSave)) {
                fs.mkdirSync(pathSave);
            }

            pathSave += '/' + year;
            pathSave = path.normalize(pathSave);
            if (!fs.existsSync(pathSave)) {
                fs.mkdirSync(pathSave);
            }

            var fileName = "";
            if (month !== null) {
                pathSave += '/' + nomsDesMois[month];
                pathSave = path.normalize(pathSave);
                if (!fs.existsSync(pathSave)) {
                    fs.mkdirSync(pathSave);
                }
                fileName = user.nom + " " + user.prenom + " " + nomsDesMois[month] + " " + year + ".xlsx";
            }
            else {
                fileName = user.nom + " " + user.prenom + " " + year + ".xlsx";
            }
            if(customFileName){
                fileName = customFileName;
            }
            pathSave += '/' + fileName;
            pathSave = path.normalize(pathSave);

            workbook.xlsx.writeFile(pathSave)
                .then(function () {
                    var conf = settingsModule.read();
                    if (user.email != "" && conf.hasOwnProperty("sendByEmail") && conf.sendByEmail == "on") {
                        emailModule.createEmail(user.email, "Feuille de " + nomsDesMois[month],
                            "Bonjour " + user.prenom + " " + user.nom + ",<br/>Vous trouverez ci-joint votre feuille pour le mois de " + nomsDesMois[month] + ".<br/><br/>Merci de ne pas répondre à cet email.",
                            pathSave).then(function () {
                                if (open) {
                                    opn(pathSave)
                                }
                                resolve();
                            })
                    } else {
                        if (open) {
                            opn(pathSave)
                        }
                        resolve();
                    }


                });
        })
    }

}