var axios;
var qs;


var self = module.exports = {
    init: function () {
        axios = require('axios');
        qs = require('qs');
    },
    getAll: function (req) {
        return new Promise((resolve, reject) => {
            axios({
                method: 'post',
                url: 'http://cordonierhoraire.cobwebsite.ch/api/user?token=' + req.session.token
            })
                .then(function (response) {
                    response = response.data;
                    resolve(response);
                })
        })
    },
    getAllNotAdmin: function (req) {
        return new Promise((resolve, reject) => {
            axios({
                method: 'post',
                url: 'http://cordonierhoraire.cobwebsite.ch/api/user/getAllNotAdmin?token=' + req.session.token
            })
                .then(function (response) {
                    response = response.data;
                    resolve(response);
                })
        })
    },
    getById: function (req, id) {
        return new Promise((resolve, reject) => {
            axios({
                method: 'post',
                url: 'http://cordonierhoraire.cobwebsite.ch/api/user/getById/' + id + '?token=' + req.session.token
            })
                .then(function (response) {
                    response = response.data;
                    resolve(response);
                })
        })
    },
    add: function (req, nom, prenom, username, password, isAdmin, email) {
        return new Promise((resolve, reject) => {
            axios({
                method: 'post',
                url: 'http://cordonierhoraire.cobwebsite.ch/api/user/add?token=' + req.session.token,
                data: qs.stringify({
                    nom: nom,
                    prenom: prenom,
                    username: username,
                    password: password,
                    isAdmin: isAdmin,
                    email: email
                })
            })
                .then(function (response) {
                    response = response.data;
                    resolve(response);
                })
        })
    },
    update: function (req, nom, prenom, username, password, isAdmin, idUser, email) {
        return new Promise((resolve, reject) => {
            if (password.length == 0) {
                axios({
                    method: 'post',
                    url: 'http://cordonierhoraire.cobwebsite.ch/api/user/updateSimple?token=' + req.session.token,
                    data: qs.stringify({
                        idUser: idUser,
                        nom: nom,
                        prenom: prenom,
                        username: username,
                        isAdmin: isAdmin,
                        email: email
                    })
                })
                    .then(function (response) {
                        response = response.data;
                        resolve(response);
                    })
            } else {
                axios({
                    method: 'post',
                    url: 'http://cordonierhoraire.cobwebsite.ch/api/user/update?token=' + req.session.token,
                    data: qs.stringify({
                        idUser: idUser,
                        nom: nom,
                        prenom: prenom,
                        username: username,
                        password: password,
                        isAdmin: isAdmin,
                        email: email
                    })
                })
                    .then(function (response) {
                        response = response.data;
                        resolve(response);
                    })
            }
        })
    }
}