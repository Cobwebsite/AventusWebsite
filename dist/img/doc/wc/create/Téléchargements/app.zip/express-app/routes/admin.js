var Router = require('../../router');
var router = new Router().getInstance();
router.prefix = '/admin';
var pug = require('pug');

function compilePug(path, opt = {}) {
  return pug.renderFile(__dirname + '/../views/' + path + '.pug', opt)
}

var req = new Router().getInstance();

var chantier = require('../modules/chantier');
var calendrier = require('../modules/calendrier');
var user = require('../modules/user');
var rapport = require('../modules/rapport');
var rapportAnnuel = require('../modules/rapportAnnuel');
var remboursement = require('../modules/remboursement');
var settings = require("../modules/settings");
var notification = require('../modules/notification');
var document_transmis = require('../modules/document_transmis');
var accident = require('../modules/accident');
var download = require('../modules/download');

var nomsDesMois = new Array("Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre");

router.addModule(chantier)
router.addModule(calendrier)
router.addModule(user)
router.addModule(rapport)
router.addModule(rapportAnnuel)
router.addModule(remboursement)
router.addModule(settings)
router.addModule(notification)
router.addModule(document_transmis)
router.addModule(accident)
router.addModule(download)


router.use((headers, body, event, next) => {
  if (headers.session.token) {
    next();
  } else {
    router.redirect("/", event);
  }
})

router.route('/', function (headers, body, event) {
  calendrier.getAllByYear(req, (new Date()).getFullYear()).then((calendar) => {
    //var nomsDesJours = new Array("Dimanche", "Lundi", "Mardi", "mercredi", "jeudi", "vendredi", "samedi") ; 
    event.res(compilePug('admin/index', {
      calendar: calendar[0],
      moisFerme: calendar[1],
      nbReponse: calendar[2],
      nomsDesMois: nomsDesMois,
      year: (new Date()).getFullYear()
    }))
  })
})

router.route('/calendar', function (headers, body, event) {
  var annee = headers.params.annee;
  calendrier.getAllByYear(req, annee).then((calendar) => {
    //var nomsDesJours = new Array("Dimanche", "Lundi", "Mardi", "mercredi", "jeudi", "vendredi", "samedi") ; 
    event.res(compilePug('admin/index', {
      calendar: calendar[0],
      moisFerme: calendar[1],
      nbReponse: calendar[2],
      nomsDesMois: nomsDesMois,
      year: annee
    }))
  })
})


router.route("/calendar/creation", function (headers, body, event) {
  var annee = headers.params.annee;
  calendrier.deleteCalendarByYear(req, annee).then(() => {
    calendrier.createCalendarRecu(req, annee, 1, 1).then(() => {
      router.redirect('/admin/calendar', event, headers, body);
    })
  })
})

router.route("/calendar/update_hours", function (headers, body, event) {
  calendrier.updateNbHeure(req, body.date, body.nbHeure).then(() => {
    event.res("");
  })
})

router.route("/calendar/validate", function (headers, body, event) {
  var year = headers.params.year;
  var month = headers.params.month;
  calendrier.closeMonth(req, year, month).then(() => {
    user.getAllNotAdmin(req).then((users) => {
      rapport.getAllMonthRapport(users, 0, year, Number(month - 1), req).then(() => {
        rapportAnnuel.getRapportYear(req, year).then(() => {
          headers.params.annee = headers.params.year;
          router.redirect("/admin/calendar", event, headers, body);
        })
      })
    })
  })
})

router.route("/calendar/reopen", function (headers, body, event) {
  var year = headers.params.year;
  var month = headers.params.month;
  calendrier.openMonth(req, year, month).then(() => {
    headers.params.annee = headers.params.year;
    router.redirect("/admin/calendar", event, headers, body);
  })
})

router.route('/calendar/import', function (headers, body, event) {
  var annee = headers.params.annee;
  calendrier.deleteCalendarByYear(req, annee).then(() => {
    calendrier.createCalendarRecuImport(req, body.import, 0).then(() => {
      router.redirect('/admin/calendar', event, headers);
    })
  })
})



/**
 * CHANTIER
 */
router.route("/chantier", function (headers, body, event) {
  chantier.getAll(req).then((chantiers) => {
    event.res(compilePug("admin/chantier", { chantiers: chantiers }))
  })
})

router.route("/chantier/add", function (headers, body, event) {
  chantier.add(req, body.chantierName).then(() => {
    router.redirect("/admin/chantier", event, headers, body);
  })
})

router.route("/chantier/update", function (headers, body, event) {
  chantier.update(req, body.idChantier, body.nom, body.isOpen).then(() => {
    event.res("");
  })
})

router.route("/chantier/excel", function (headers, body, event) {
  chantier.rapport(req, headers.params.id).then(() => {
    event.res("");
  })
})


/**
 * USER
 */
router.route('/user', function (headers, body, event) {
  user.getAll(req).then((users) => {
    event.res(compilePug("admin/users", {
      users: users
    }))
  })
})

router.route('/user/add', function (headers, body, event) {
  user.add(req, body.nom, body.prenom, body.username, body.password, body.isAdmin, body.email).then(() => {
    router.redirect("/admin/user", event);
  })
})

router.route('/user/details', function (headers, body, event) {
  user.getById(req, headers.params.id).then((user) => {
    var year = new Date().getFullYear() - 2;
    var years = [];
    for (var i = year; i < year + 5; i++) {
      years.push(i);
    }
    event.res(compilePug("admin/user", {
      user: user,
      nomsDesMois: nomsDesMois,
      years: years,
      currentYear: new Date().getFullYear(),
      currentMonth: new Date().getMonth()
    }))
  })
})

router.route("/user/update", function (headers, body, event) {
  user.update(req, body.nom, body.prenom, body.username, body.password, body.isAdmin, headers.params.id, body.email).then((user) => {
    router.redirect("/admin/user/details", event, headers);
  })
})

router.route("/user/rapport", function (headers, body, event) {
  user.getById(req, headers.params.id).then((u) => {
    if (headers.params.fullYear) {
      rapport.getOneRapportFullYear(u, headers.params.annee, req, true).then(() => {
        event.res("");
      })
    }
    else {
      rapport.getOneRapport(u, headers.params.annee, headers.params.mois, req, true).then(() => {
        event.res("");
      })
    }
  })
})

router.route("/user/rapport_det", function (headers, body, event) {
  user.getById(req, headers.params.id).then((u) => {
    if (headers.params.fullYear) {
      rapport.getOneRapportDetailsFullYear(u, headers.params.annee, req, true).then(() => {
        event.res("");
      })
    }
    else {
      rapport.getOneRapportDetails(u, headers.params.annee, headers.params.mois, req, true).then(() => {
        event.res("");
      })
    }
  })
})

/**
 * REMBOURSEMENT
 */

router.route('/remboursement', function (headers, body, event) {
  remboursement.getAll(req).then((rembs) => {
    event.res(compilePug("admin/remboursement", {
      rembs: rembs
    }))
  })
})

router.route("/remboursement/done", function (headers, body, event) {
  remboursement.close(req, headers.params.id).then(() => {
    router.redirect("/admin/remboursement", event);
  })
})

router.route("/remboursement/cancel", function (headers, body, event) {
  remboursement.reopen(req, headers.params.id).then(() => {
    router.redirect("/admin/remboursement", event);
  })
})



/**
 * SETTINGS
 */
router.route('/settings', function (headers, body, event) {
  var conf = settings.read();
  settings.getNotificationEmail(req).then((emailContact) => {
    conf.email = emailContact.email;
    event.res(compilePug("admin/settings", conf))
  })
})
router.route('/settings/save', function (headers, body, event) {
  settings.setNotificationEmail(req, body.email).then(() => {
    delete body.email;
    settings.write(body);
    router.redirect("/admin/settings", event);
  })

})



/**
 * NOTIFICATION
 */

router.route('/notif', function (headers, body, event) {
  notification.getAll(req).then((notifs) => {
    event.res(compilePug('admin/notification', { notifs: notifs }));
  })
})

router.route('/notif/add', function (headers, body, event) {
  notification.create(req, body).then(() => {
    router.redirect('/admin/notif', event);
  })
})


/**
 * document_transmis
 */
router.route('/document_transmis', function (headers, body, event) {
  document_transmis.getAll(req).then((documents) => {
    event.res(compilePug('admin/document_transmis', { documents: documents }))
  })
})


/**
 * Accident
 */
router.route('/accident', function (headers, body, event) {
  accident.getAll(req).then((accidents) => {
    event.res(compilePug('admin/accident', { accidents: accidents }))
  })
})

router.route('/accident/details', function (headers, body, event) {
  accident.getById(req, headers.params.id).then((accident) => {
    event.res(compilePug('admin/accident_details', { accident: accident }))
  })
})


/**
 * Download
 */
router.route('/download', function (headers, body, event) {
  download.getAll(req).then((downloads) => {
    event.res(compilePug('admin/download', { token: req.session.token, downloads: downloads }))
  })
})

router.route('/download/add', function (headers, body, event) {
  download.add(req, body).then(() => {
    router.redirect('/admin/download', event);
  })
})

router.route('/download/delete', function (headers, body, event) {
  download.delete(req, headers.params.id).then(() => {
    router.redirect('/admin/download', event);
  })
})
