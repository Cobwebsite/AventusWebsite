const { app, BrowserWindow, ipcMain } = require('electron');
var Router = require('./router');
var router = new Router().getInstance();
router.reload();

const update = require('./update');

ipcMain.on('navigation', (event, arg) => {
    arg = JSON.parse(arg);
    router.serve(arg.headers.url, arg.headers, arg.body, event);
})

var mainWindow
app.on("ready", function () {
    checkUpdate();
});
app.on("browser-window-created", function (e, window) {
    window.setMenu(null);
    
});

app.on("window-all-closed", function () {
    if (process.platform !== "darwin") {
        app.quit();
    }
});


function createWindow() {
    let displays = require('electron').screen.getAllDisplays()
    // let mainDisplay = displays.find((display) => {
    //     return display.bounds.x === 0 || display.bounds.y === 0
    // })
    mainWindow = new BrowserWindow({
        // x: externalDisplay.bounds.x + 50,
        // y: externalDisplay.bounds.y + 50,
        autoHideMenuBar: true,
        width: 600,
        height: 400,
        show: false,
        icon: __dirname + "/logo.ico",
        webPreferences: {
            nodeIntegration: true
        },
    });
    //
    mainWindow.maximize();
    mainWindow.loadURL(`file://${__dirname}/index.html`);
    //mainWindow.webContents.openDevTools();


    mainWindow.on('close', () => {
        //mainWindow.webContents.send('stop-server');
    });
    mainWindow.on("closed", () => {
        mainWindow = null;
    });
}

function checkUpdate() {
    update.needUpdate().then((isNeeded) => {
        if (isNeeded) {
            update.updating()
        } else {
            createWindow();
        }
    })

}